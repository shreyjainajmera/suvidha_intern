<?php
include("connection.php"); 
if(!empty($_POST['submit']))
{
    $name= $_POST['fname']." ".$_POST['lname'];
}
require("fpdf.php");
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont("Arial","",16);
$pdf->Cell(0,10,"Details ",1,1,'C');
$pdf->output();
?>

