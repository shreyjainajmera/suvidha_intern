<?php
$con=mysqli_connect("localhost","root","","responsiveform");
error_reporting(0);
$res=mysqli_query($con,"select * from form");
if(mysqli_num_rows($res)>0){
	header('content-type:image/jpeg');
	$font="BRUSHSCI.TTF";
	$image=imagecreatefromjpeg("certificate.jpg");
	$color=imagecolorallocate($image,19,21,22);
	while($row=mysqli_fetch_assoc($res)){
		$name=$row['fname'];
		imagettftext($image,50,0,365,420,$color,$font,$name);
		$date="6th may 2020";
		imagettftext($image,20,0,450,595,$color,"AGENCYR.TTF",$date);
		$file=time();
		imagejpeg($image,"certificate/".$file.".jpg");
		imagedestroy($image);
		//mysqli_query($con,"update student set status=1 where id='".$file."'");
	}
}
?>